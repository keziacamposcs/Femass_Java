public interface CalculoValor {
    public double calcular(ContaEstacionamento inicio, ContaEstacionamento fim);
}
