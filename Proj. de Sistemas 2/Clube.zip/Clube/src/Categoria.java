public class Categoria {
    private String des_cat;
    public Categoria (String des_cat)
    {
        this.des_cat = des_cat;
    }

    public String getDes_cat() {
        return des_cat;
    }

    public void setDes_cat(String des_cat) {
        this.des_cat = des_cat;
    }
}
