package com.mycompany.mavenproject1;

public class Terreno extends Imovel
{
    public Terreno (String t,double v, String b, double met)
    {
        super(t,v,b,met);
    }
}
