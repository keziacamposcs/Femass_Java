package com.mycompany.mavenproject1;

public class Casa extends Residencial
{
    public Casa (int vg, int qtq, int qts)
    {
        super(vg, qtq, qts);
    }
}
