package com.mycompany.projeto;

public class Figura 
{
    public static void main(String[] args)
    {
         
   }
}