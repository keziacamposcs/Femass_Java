package br.edu.femass.filmes.dao;

import br.edu.femass.filmes.model.Filme;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilmeDao implements Dao<Filme>{
    private static final String ARQUIVO = "filme.json";
    private static FilmeDados filmeDados = new FilmeDados();

    @Override
    public void gravar(Filme objeto) throws Exception {
        listar();
        filmeDados.getFilmes().add(objeto);

        ObjectMapper mapper = new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.writeValue(new File(ARQUIVO), filmeDados);

    }

    @Override
    public List<Filme> listar() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        FileReader fr = new FileReader(ARQUIVO);
        filmeDados = mapper.readValue(fr, FilmeDados.class);

        return filmeDados.getFilmes();
    }

    @Override
    public void excluir(Filme objeto) throws Exception {
        filmeDados.getFilmes().remove(objeto);
    }
}
