package br.edu.femass.filmes.dao;

import br.edu.femass.filmes.model.Filme;

import java.util.ArrayList;
import java.util.List;

public class FilmeDados {
    private List<Filme> filmes = new ArrayList<Filme>();

    public List<Filme> getFilmes() {
        return filmes;
    }

    public void setFilmes(List<Filme> filmes) {
        this.filmes = filmes;
    }
}
