package br.edu.femass.filmes.gui;

import br.edu.femass.filmes.dao.FilmeDao;
import br.edu.femass.filmes.model.ClassificacaoFilme;
import br.edu.femass.filmes.model.Filme;
import br.edu.femass.filmes.model.GeneroFilme;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class FilmeController implements Initializable {

    private FilmeDao filmeDao = new FilmeDao();

    @FXML
    private ListView<Filme> LstFilmes;

    @FXML
    private Button BtnIncluir;

    @FXML
    private Button BtnExcluir;

    @FXML
    private Button BtnGravar;

    @FXML
    private Button BtnCancelar;

    @FXML
    private TextField TxtCodigo;

    @FXML
    private TextField TxtNome;

    @FXML
    private TextField TxtDuracao;

    @FXML
    private TextField TxtAnoLancamento;

    @FXML
    private TextField TxtDiretor;

    @FXML
    private ComboBox<ClassificacaoFilme> CboClassificacao;

    @FXML
    private ComboBox<GeneroFilme> CboGenero;


    private void limparTela() {
        TxtCodigo.setText("");
        TxtAnoLancamento.setText("");
        TxtDiretor.setText("");
        TxtDuracao.setText("");
        TxtNome.setText("");
        CboClassificacao.setValue(null);
        CboGenero.setValue(null);
    }
    private void habilitarInterface(Boolean incluir) {
        TxtAnoLancamento.setDisable(!incluir);
        TxtDiretor.setDisable(!incluir);
        TxtDuracao.setDisable(!incluir);
        TxtNome.setDisable(!incluir);
        CboClassificacao.setDisable(!incluir);
        CboGenero.setDisable(!incluir);
        BtnGravar.setDisable(!incluir);
        BtnCancelar.setDisable(!incluir);
        BtnExcluir.setDisable(incluir);
        BtnIncluir.setDisable(incluir);

        LstFilmes.setDisable(incluir);
    }

    private void exibirFilme() {
        Filme filme = LstFilmes.getSelectionModel().getSelectedItem();
        if (filme==null) return;
        TxtNome.setText(filme.getNome());
        TxtDuracao.setText(filme.getDuracao().toString());
        TxtDiretor.setText(filme.getDiretor());
        TxtAnoLancamento.setText(filme.getAnoLancamento().toString());
        TxtCodigo.setText(filme.getCodigo().toString());
        CboGenero.setValue(filme.getGenero());
        CboClassificacao.setValue(filme.getClassificacao());

    }

    @FXML
    private void LstFilmes_MouseClicked(MouseEvent evento) {
        exibirFilme();
    }

    @FXML
    private void LstFilmes_KeyPressed(KeyEvent evento) {
        exibirFilme();
    }

    @FXML
    private void BtnIncluir_Action(ActionEvent evento) {
        habilitarInterface(true);
        limparTela();
        TxtNome.requestFocus();
    }

    @FXML
    private void BtnExcluir_Action(ActionEvent evento) {
        Filme filme = LstFilmes.getSelectionModel().getSelectedItem();

        if (filme==null) return;

        try {
            filmeDao.excluir(filme);
        } catch (Exception e) {
            e.printStackTrace();
        }

        atualizarLista();

    }
    @FXML
    private void BtnGravar_Action(ActionEvent evento) {
        Filme filme = new Filme();
        filme.setClassificacao(CboClassificacao.getValue());
        filme.setAnoLancamento(Integer.parseInt(TxtAnoLancamento.getText()));
        filme.setDiretor(TxtDiretor.getText());
        filme.setDuracao(Integer.parseInt(TxtDuracao.getText()));
        filme.setGenero(CboGenero.getValue());
        filme.setNome(TxtNome.getText());
        try {
            filmeDao.gravar(filme);
        } catch (Exception e) {
            e.printStackTrace();
        }
        atualizarLista();
        habilitarInterface(false);
    }
    @FXML
    private void BtnCancelar_Action(ActionEvent evento) {
        habilitarInterface(false);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<ClassificacaoFilme> classificacoes = FXCollections.observableArrayList(ClassificacaoFilme.values());
        CboClassificacao.setItems(classificacoes);

        ObservableList<GeneroFilme> generos = FXCollections.observableArrayList(GeneroFilme.values());
        CboGenero.setItems(generos);

        atualizarLista();
    }


    private void atualizarLista() {
        List<Filme> filmes = null;
        try {
            filmes = filmeDao.listar();
        } catch (Exception e) {
            filmes = new ArrayList<Filme>();
        }
        ObservableList<Filme> filmesOb = FXCollections.observableArrayList(filmes);
        LstFilmes.setItems(filmesOb);
    }
}