package br.edu.femass.filmes.model;

public enum ClassificacaoFilme {
    livre("Classificação Livre"),
    dez("Classificação 10 anos"),
    doze("Classificação 12 anos"),
    quatorze("Classificação 14 anos"),
    dezesseis("Classificação 16 anos"),
    dezoito("Classificação 18 anos");

    private String nome;

    ClassificacaoFilme(String nome) {
        this.nome = nome;
    }

}
