package br.edu.femass.filmes.model;

public enum GeneroFilme {
    acao("Filme de Ação"),
    comedia("Filme de Comédia"),
    terror("Filme de Terror"),
    suspense("Filme de Suspense"),
    ficcao("Filme de Ficção Científica");

    private String nome;

    GeneroFilme(String nome) {
        this.nome = nome;
    }

}
