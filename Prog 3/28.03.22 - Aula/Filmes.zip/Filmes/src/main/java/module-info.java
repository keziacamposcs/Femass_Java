module br.edu.femass.filmes {
    requires javafx.controls;
    requires javafx.fxml;
    requires lombok;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.databind;


    opens br.edu.femass.filmes to javafx.fxml;
    exports br.edu.femass.filmes;
    exports br.edu.femass.filmes.gui;
    exports br.edu.femass.filmes.model;
    exports br.edu.femass.filmes.dao;
    opens br.edu.femass.filmes.gui to javafx.fxml;
}