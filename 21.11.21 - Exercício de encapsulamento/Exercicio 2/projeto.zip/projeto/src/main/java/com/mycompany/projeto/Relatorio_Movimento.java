package com.mycompany.projeto;

public class Relatorio_Movimento extends Conta
{
        public double emitir (Conta conta)
        {
            return(this.saldo);
        }
}
